// ACPC Cutoff static app — vanilla JS, no build step.

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const fmt = n => n.toLocaleString('en-IN');

const STATE = {
  data: null,
  shortlist: JSON.parse(localStorage.getItem('acpc.shortlist') || '[]'),
  compare: [],
  lastPredict: null,
};

const saveShortlist = () => {
  localStorage.setItem('acpc.shortlist', JSON.stringify(STATE.shortlist));
  $('#shortlist-count').textContent = STATE.shortlist.length ? `(${STATE.shortlist.length})` : '';
};

// ----- TABS -----
function showTab(name) {
  $$('[data-panel]').forEach(s => s.hidden = s.dataset.panel !== name);
  $$('.tab-btn').forEach(b => {
    const active = b.dataset.tab === name;
    b.classList.toggle('bg-indigo-600', active);
    b.classList.toggle('text-white', active);
    b.classList.toggle('text-slate-600', !active);
    b.classList.toggle('hover:bg-slate-100', !active);
  });
  history.replaceState(null, '', `#${name}`);
  if (name === 'shortlist') renderShortlist();
  if (name === 'compare') renderCompareControls();
  if (name === 'colleges') renderColleges();
  if (name === 'branches') renderBranches();
}

// ----- BUCKETS -----
function bucket(rank, lastRank) {
  const delta = lastRank - rank;
  if (delta >= 2000) return 'safe';
  if (delta >= -1000) return 'mid';
  if (delta >= -5000) return 'reach';
  return null;
}
const BUCKET_META = {
  safe:  { label: '🟢 Likely', color: 'bg-emerald-50 border-emerald-200', chip: 'bg-emerald-100 text-emerald-800' },
  mid:   { label: '🟡 Maybe',  color: 'bg-amber-50 border-amber-200',     chip: 'bg-amber-100 text-amber-800' },
  reach: { label: '🔴 Reach',  color: 'bg-rose-50 border-rose-200',       chip: 'bg-rose-100 text-rose-800' },
};

// ----- PREDICT -----
function rowKey(r) { return `${r.institute}::${r.branch}::${r.category}::${r.type}`; }
function isSaved(r) { return STATE.shortlist.some(s => s.key === rowKey(r)); }

function toggleSave(r, btn) {
  const k = rowKey(r);
  const i = STATE.shortlist.findIndex(s => s.key === k);
  if (i >= 0) STATE.shortlist.splice(i, 1);
  else STATE.shortlist.push({ key: k, ...r });
  saveShortlist();
  if (btn) btn.textContent = isSaved(r) ? '⭐ Saved' : '☆ Save';
}

function rowCard(r, bk) {
  const meta = BUCKET_META[bk] || { color: 'bg-white border-slate-200', chip: 'bg-slate-100 text-slate-700' };
  const saved = isSaved(r);
  const el = document.createElement('div');
  el.className = `border rounded-lg p-3 ${meta.color} flex flex-wrap items-center gap-2`;
  el.innerHTML = `
    <div class="flex-1 min-w-0">
      <div class="font-semibold text-sm leading-snug">${r.institute}</div>
      <div class="text-xs text-slate-600 mt-0.5">${r.branch}</div>
      <div class="flex flex-wrap gap-1 mt-1.5">
        <span class="text-xs px-2 py-0.5 rounded-full ${meta.chip}">${meta.label || ''}</span>
        <span class="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">${r.category}</span>
        <span class="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">${r.type}</span>
      </div>
    </div>
    <div class="text-right">
      <div class="text-xs text-slate-500">Closing rank</div>
      <div class="text-lg font-bold tabular-nums">${fmt(r.last_rank)}</div>
      <div class="text-[10px] text-slate-400">opens ${fmt(r.first_rank)}</div>
    </div>
    <button class="save-btn text-sm px-2 py-1 rounded-md border bg-white hover:bg-slate-50">${saved ? '⭐ Saved' : '☆ Save'}</button>
  `;
  el.querySelector('.save-btn').addEventListener('click', e => toggleSave(r, e.currentTarget));
  return el;
}

function populateBranchPicker(group) {
  const bp = $('#branchPickPredict');
  if (!bp) return;
  const branches = group ? (STATE.data.branch_groups[group] || []) : STATE.data.branches;
  bp.innerHTML = `<option value="">${group ? `All in ${group} (${branches.length})` : 'All in selected group'}</option>` +
    branches.map(b => `<option>${b}</option>`).join('');
}

function runPredict(opts) {
  const { rank, category, type, branch, group, quota } = opts;
  const q = quota || 'GUJCET_Rank';
  const matches = STATE.data.rows.filter(r => {
    if (r.quota !== q) return false;
    if (category && r.category !== category) return false;
    if (type && r.type !== type) return false;
    if (group && r.branch_group !== group) return false;
    if (branch && r.branch !== branch) return false;
    const bk = bucket(rank, r.last_rank);
    return bk !== null;
  }).map(r => ({ r, bk: bucket(rank, r.last_rank) }));

  matches.sort((a, b) => {
    const order = { safe: 0, mid: 1, reach: 2 };
    if (order[a.bk] !== order[b.bk]) return order[a.bk] - order[b.bk];
    return Math.abs(a.r.last_rank - rank) - Math.abs(b.r.last_rank - rank);
  });

  const counts = { safe: 0, mid: 0, reach: 0 };
  matches.forEach(m => counts[m.bk]++);

  $('#bucket-counts').hidden = false;
  $('#cnt-safe').textContent = counts.safe;
  $('#cnt-mid').textContent = counts.mid;
  $('#cnt-reach').textContent = counts.reach;

  const summary = $('#predict-summary');
  summary.hidden = false;
  const qLabel = q === 'All India_Rank' ? 'JEE Main' : 'GUJCET';
  summary.innerHTML = `Showing <b>${matches.length}</b> matches for <b>${qLabel}</b> rank <b>${fmt(rank)}</b>${category ? ` · ${category}` : ''}${type ? ` · ${type}` : ''}${group ? ` · ${group}` : ''}${branch ? ` · ${branch}` : ''}.`;

  const container = $('#predict-results');
  container.innerHTML = '';
  if (matches.length === 0) {
    container.innerHTML = `<div class="bg-white border rounded-lg p-6 text-center text-slate-500">No matches. Try widening category or removing filters.</div>`;
    return;
  }
  // group by bucket
  ['safe', 'mid', 'reach'].forEach(bk => {
    const subset = matches.filter(m => m.bk === bk);
    if (!subset.length) return;
    const h = document.createElement('h3');
    h.className = 'mt-4 mb-1 font-bold text-sm text-slate-700';
    h.textContent = `${BUCKET_META[bk].label} · ${subset.length}`;
    container.appendChild(h);
    subset.slice(0, 200).forEach(m => container.appendChild(rowCard(m.r, m.bk)));
    if (subset.length > 200) {
      const more = document.createElement('div');
      more.className = 'text-xs text-slate-500 text-center py-2';
      more.textContent = `…and ${subset.length - 200} more`;
      container.appendChild(more);
    }
  });

  // shareable URL
  const params = new URLSearchParams({ rank, quota: q, category: category || '', type: type || '', group: group || '', branch: branch || '' });
  const link = $('#share-link');
  link.hidden = false;
  link.href = `${location.pathname}#predict?${params}`;
  link.onclick = e => {
    e.preventDefault();
    const url = `${location.origin}${location.pathname}#predict?${params}`;
    navigator.clipboard?.writeText(url);
    link.textContent = '✓ Link copied';
    setTimeout(() => link.textContent = '🔗 Share this result', 1500);
  };

  STATE.lastPredict = opts;
}

// ----- COLLEGES -----
const collegeFilters = { q: '', city: '', type: '', under50k: false, under1L: false };
function collegeMatches(c) {
  const q = collegeFilters.q.toLowerCase();
  if (q) {
    const hay = (c.name + ' ' + c.city + ' ' + c.branches.join(' ')).toLowerCase();
    if (!hay.includes(q)) return false;
  }
  if (collegeFilters.city && c.city !== collegeFilters.city) return false;
  if (collegeFilters.type && c.type !== collegeFilters.type) return false;
  if (collegeFilters.under50k && c.fee_min > 50000) return false;
  if (collegeFilters.under1L && c.fee_min > 100000) return false;
  return true;
}
function renderColleges() {
  const list = $('#collegeList');
  list.innerHTML = '';
  const colleges = (STATE.data.colleges || []).filter(collegeMatches);
  $('#collegeCount').textContent = `${colleges.length} colleges`;
  colleges.slice(0, 300).forEach(c => {
    const typeChip = c.type === 'Govt/GIA'
      ? 'bg-emerald-100 text-emerald-800'
      : 'bg-indigo-100 text-indigo-800';
    const card = document.createElement('button');
    card.className = 'text-left bg-white border rounded-lg p-3 hover:bg-indigo-50 hover:border-indigo-300 transition';
    card.innerHTML = `
      <div class="flex items-start justify-between gap-2">
        <div class="font-semibold text-sm leading-snug flex-1 min-w-0">${c.name}</div>
        <span class="text-[10px] px-1.5 py-0.5 rounded-full ${typeChip} shrink-0">${c.type === 'Govt/GIA' ? 'Govt' : 'Private'}</span>
      </div>
      <div class="flex flex-wrap items-center gap-2 mt-2 text-xs text-slate-600">
        <span>📍 ${c.city}</span>
        <span>📚 ${c.branch_count} branches</span>
      </div>
      <div class="flex flex-wrap items-center justify-between gap-2 mt-2 text-xs">
        <span class="text-slate-700">💰 <b>${c.fee_label}</b></span>
        ${c.min_cutoff_gen ? `<span class="text-slate-500">GEN cutoff <b class="text-slate-900 tabular-nums">${fmt(c.min_cutoff_gen)}–${fmt(c.max_cutoff_gen)}</b></span>` : ''}
      </div>`;
    card.onclick = () => showCollegeDetail(c.name);
    list.appendChild(card);
  });
  if (!colleges.length) list.innerHTML = '<div class="col-span-full text-slate-500 text-sm bg-white border rounded-lg p-6 text-center">No colleges match. Loosen filters.</div>';
}
function showCollegeDetail(name) {
  const c = (STATE.data.colleges || []).find(x => x.name === name);
  const rows = STATE.data.rows.filter(r => r.institute === name && r.quota === 'GUJCET_Rank').sort((a, b) => a.last_rank - b.last_rank);
  const wrap = $('#collegeDetail');
  const mapQ = encodeURIComponent(name);
  const websiteQ = encodeURIComponent(name + ' official site');
  wrap.innerHTML = `
    <div class="bg-white rounded-xl shadow-sm p-4">
      <div class="flex items-start justify-between gap-2 flex-wrap mb-3">
        <div class="min-w-0">
          <h3 class="font-bold leading-snug">${name}</h3>
          <div class="text-xs text-slate-500 mt-1 flex flex-wrap gap-x-3 gap-y-1">
            <span>📍 ${c?.city || '—'}</span>
            <span>🏷️ ${c?.type || '—'}</span>
            <span>📚 ${c?.branch_count || rows.length} branches</span>
          </div>
        </div>
        <button class="text-xs text-indigo-600 underline shrink-0" id="closeDetail">✕ close</button>
      </div>

      <div class="grid sm:grid-cols-3 gap-2 mb-4 text-xs">
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">Approx. tuition</div>
          <div class="font-bold text-base text-slate-900">${c?.fee_label || '—'}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">${c?.fee_note || ''}</div>
        </div>
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">GEN cutoff range</div>
          <div class="font-bold text-base text-slate-900 tabular-nums">${c?.min_cutoff_gen ? fmt(c.min_cutoff_gen) + '–' + fmt(c.max_cutoff_gen) : '—'}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">across all branches</div>
        </div>
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">Quick links</div>
          <div class="flex flex-col gap-1 mt-1">
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${mapQ}">🗺️ View on map</a>
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://www.google.com/search?q=${websiteQ}">🔗 Find website</a>
          </div>
        </div>
      </div>

      <div class="overflow-auto -mx-4 px-4">
        <table class="w-full text-sm min-w-[480px]">
          <thead class="text-xs text-slate-500 text-left">
            <tr><th class="py-1">Branch</th><th>Cat</th><th class="text-right">Open</th><th class="text-right">Close</th><th></th></tr>
          </thead>
          <tbody>${rows.map(r => `
            <tr class="border-t">
              <td class="py-1 pr-2">${r.branch}</td>
              <td><span class="text-xs px-1.5 rounded bg-slate-100">${r.category}</span></td>
              <td class="text-right tabular-nums">${fmt(r.first_rank)}</td>
              <td class="text-right tabular-nums font-semibold">${fmt(r.last_rank)}</td>
              <td><button data-key='${rowKey(r)}' class="save-tiny text-xs underline">${isSaved(r) ? '⭐' : '☆'}</button></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
  $('#closeDetail').onclick = () => wrap.innerHTML = '';
  wrap.querySelectorAll('.save-tiny').forEach(b => {
    b.onclick = () => {
      const r = rows.find(x => rowKey(x) === b.dataset.key);
      toggleSave(r); b.textContent = isSaved(r) ? '⭐' : '☆';
    };
  });
  wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ----- BRANCHES -----
let branchFilter = '';
function renderBranches() {
  const list = $('#branchList');
  list.innerHTML = '';
  const q = branchFilter.toLowerCase();
  const filtered = STATE.data.branches.filter(n => n.toLowerCase().includes(q)).slice(0, 200);
  filtered.forEach(name => {
    const rowsForBranch = STATE.data.rows.filter(r => r.branch === name);
    const colleges = new Set(rowsForBranch.map(r => r.institute));
    const minCut = Math.min(...rowsForBranch.map(r => r.last_rank));
    const card = document.createElement('button');
    card.className = 'text-left bg-white border rounded-lg p-3 hover:bg-indigo-50';
    card.innerHTML = `
      <div class="font-semibold text-sm">${name}</div>
      <div class="text-xs text-slate-500 mt-1">${colleges.size} colleges · best cutoff ${fmt(minCut)}</div>`;
    card.onclick = () => showBranchDetail(name);
    list.appendChild(card);
  });
  if (!filtered.length) list.innerHTML = '<div class="text-slate-500 text-sm">No matches.</div>';
}
function showBranchDetail(name) {
  const rows = STATE.data.rows.filter(r => r.branch === name && r.quota === 'GUJCET_Rank').sort((a, b) => a.last_rank - b.last_rank);
  const wrap = $('#branchDetail');
  wrap.innerHTML = `
    <div class="bg-white rounded-xl shadow-sm p-4">
      <div class="flex items-center justify-between gap-2 flex-wrap mb-3">
        <h3 class="font-bold">${name}</h3>
        <button class="text-xs text-indigo-600 underline" id="closeBDetail">close</button>
      </div>
      <div class="overflow-auto"><table class="w-full text-sm">
        <thead class="text-xs text-slate-500 text-left"><tr><th class="py-1">College</th><th>Cat</th><th>Type</th><th class="text-right">Close</th><th></th></tr></thead>
        <tbody>${rows.map(r => `
          <tr class="border-t">
            <td class="py-1 pr-2">${r.institute}</td>
            <td><span class="text-xs px-1.5 rounded bg-slate-100">${r.category}</span></td>
            <td class="text-xs">${r.type}</td>
            <td class="text-right tabular-nums font-semibold">${fmt(r.last_rank)}</td>
            <td><button data-key='${rowKey(r)}' class="save-tiny text-xs underline">${isSaved(r) ? '⭐' : '☆'}</button></td>
          </tr>`).join('')}</tbody></table></div>
    </div>`;
  $('#closeBDetail').onclick = () => wrap.innerHTML = '';
  wrap.querySelectorAll('.save-tiny').forEach(b => {
    b.onclick = () => {
      const r = rows.find(x => rowKey(x) === b.dataset.key);
      toggleSave(r); b.textContent = isSaved(r) ? '⭐' : '☆';
    };
  });
}

// ----- COMPARE -----
function renderCompareControls() {
  const sel = $('#compareAdd');
  sel.innerHTML = '<option value="">+ Add a college…</option>' +
    STATE.data.institutes
      .filter(n => !STATE.compare.includes(n))
      .map(n => `<option value="${n.replace(/"/g, '&quot;')}">${n}</option>`).join('');
  renderCompareTable();
}
function renderCompareTable() {
  const wrap = $('#compareTable');
  if (!STATE.compare.length) { wrap.innerHTML = '<div class="text-slate-500 text-sm">Pick a college above to start comparing.</div>'; return; }
  const allBranches = [...new Set(STATE.data.rows.filter(r => STATE.compare.includes(r.institute) && r.category === 'GEN' && r.quota === 'GUJCET_Rank').map(r => r.branch))].sort();
  wrap.innerHTML = `
    <div class="bg-white rounded-xl shadow-sm p-3 overflow-auto">
      <div class="mb-2 flex flex-wrap gap-2">${STATE.compare.map(n => `<span class="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full">${n} <button data-rm="${n.replace(/"/g, '&quot;')}" class="ml-1 font-bold">×</button></span>`).join('')}</div>
      <table class="w-full text-xs">
        <thead><tr class="text-left text-slate-500"><th class="py-1 pr-2">Branch (GEN closing rank)</th>${STATE.compare.map(n => `<th class="text-right pr-3">${n.split(',')[0].slice(0, 30)}</th>`).join('')}</tr></thead>
        <tbody>${allBranches.map(b => `
          <tr class="border-t"><td class="py-1 pr-2">${b}</td>${STATE.compare.map(n => {
            const row = STATE.data.rows.find(r => r.institute === n && r.branch === b && r.category === 'GEN' && r.quota === 'GUJCET_Rank');
            return `<td class="text-right tabular-nums pr-3">${row ? fmt(row.last_rank) : '<span class="text-slate-300">–</span>'}</td>`;
          }).join('')}</tr>`).join('')}</tbody>
      </table>
      <p class="text-[10px] text-slate-400 mt-2">Showing GEN category closing ranks. Use Predict tab for other categories.</p>
    </div>`;
  wrap.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => {
    STATE.compare = STATE.compare.filter(n => n !== b.dataset.rm);
    renderCompareControls();
  });
}

// ----- SHORTLIST -----
function renderShortlist() {
  const wrap = $('#shortlistView');
  if (!STATE.shortlist.length) {
    wrap.innerHTML = `<div class="bg-white border rounded-lg p-6 text-center text-slate-500">No saved colleges yet. Hit ☆ Save on any result.</div>`;
    return;
  }
  wrap.innerHTML = `<div class="bg-white rounded-xl shadow-sm overflow-auto"><table class="w-full text-sm">
    <thead class="text-xs text-slate-500 text-left"><tr><th class="py-2 px-3">College</th><th>Branch</th><th>Cat</th><th>Type</th><th class="text-right pr-3">Close</th><th></th></tr></thead>
    <tbody>${STATE.shortlist.map(r => `
      <tr class="border-t">
        <td class="py-1 px-3">${r.institute}</td><td>${r.branch}</td>
        <td><span class="text-xs px-1.5 rounded bg-slate-100">${r.category}</span></td>
        <td class="text-xs">${r.type}</td>
        <td class="text-right tabular-nums font-semibold pr-3">${fmt(r.last_rank)}</td>
        <td><button data-rm="${r.key}" class="text-rose-600 text-xs">remove</button></td>
      </tr>`).join('')}</tbody></table></div>`;
  wrap.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => {
    STATE.shortlist = STATE.shortlist.filter(s => s.key !== b.dataset.rm);
    saveShortlist(); renderShortlist();
  });
}

function shareWhatsApp() {
  if (!STATE.shortlist.length) return;
  const lines = STATE.shortlist.map((r, i) => `${i + 1}. ${r.institute} — ${r.branch} (${r.category}, close ${fmt(r.last_rank)})`).join('\n');
  const msg = `My ACPC shortlist:\n\n${lines}\n\nSource: ${location.origin}${location.pathname}`;
  window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
}

// ----- INIT -----
async function loadData() {
  const res = await fetch('data/data.json');
  STATE.data = await res.json();
  const m = STATE.data.meta;
  $('#meta-line').textContent = `${m.round} · A.Y. ${m.year} · ${fmt(m.rows)} cutoffs · ${fmt(STATE.data.institutes.length)} colleges`;

  // group + branch pickers on predict
  const groups = STATE.data.branch_groups || {};
  const gp = $('#groupPickPredict');
  if (gp) {
    const entries = Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
    gp.innerHTML = '<option value="">All branches</option>' +
      entries.map(([g, bs]) => `<option value="${g}">${g} (${bs.length})</option>`).join('');
  }
  populateBranchPicker('');

  // city dropdown for college tab
  const cityEl = $('#collegeCity');
  if (cityEl && STATE.data.cities) {
    cityEl.innerHTML = '<option value="">All cities</option>' + STATE.data.cities.map(c => `<option>${c}</option>`).join('');
  }
}

function wireEvents() {
  $('#tabs').addEventListener('click', e => {
    const b = e.target.closest('.tab-btn'); if (b) showTab(b.dataset.tab);
  });
  $('#predict-form').addEventListener('submit', e => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    runPredict({
      rank: +fd.get('rank'),
      category: fd.get('category'),
      type: fd.get('type'),
      quota: fd.get('quota') || 'GUJCET_Rank',
      group: $('#groupPickPredict')?.value || '',
      branch: $('#branchPickPredict')?.value || '',
    });
  });
  $('#groupPickPredict')?.addEventListener('change', e => populateBranchPicker(e.target.value));
  $('#collegeSearch').addEventListener('input', e => { collegeFilters.q = e.target.value; renderColleges(); });
  $('#collegeCity').addEventListener('change', e => { collegeFilters.city = e.target.value; renderColleges(); });
  $('#collegeType').addEventListener('change', e => { collegeFilters.type = e.target.value; renderColleges(); });
  $('#feeUnder50k').addEventListener('change', e => { collegeFilters.under50k = e.target.checked; if (e.target.checked) { $('#feeUnder1L').checked = false; collegeFilters.under1L = false; } renderColleges(); });
  $('#feeUnder1L').addEventListener('change', e => { collegeFilters.under1L = e.target.checked; if (e.target.checked) { $('#feeUnder50k').checked = false; collegeFilters.under50k = false; } renderColleges(); });
  $('#branchSearch').addEventListener('input', e => { branchFilter = e.target.value; renderBranches(); });
  $('#compareAdd').addEventListener('change', e => {
    const v = e.target.value;
    if (v && STATE.compare.length < 4 && !STATE.compare.includes(v)) STATE.compare.push(v);
    renderCompareControls();
  });
  $('#shareWA').onclick = shareWhatsApp;
  $('#printList').onclick = () => window.print();
  $('#clearList').onclick = () => { if (confirm('Clear all saved colleges?')) { STATE.shortlist = []; saveShortlist(); renderShortlist(); } };
}

function applyHashState() {
  const [tab, qs] = (location.hash.slice(1) || 'predict').split('?');
  showTab(['predict','colleges','branches','compare','shortlist','about'].includes(tab) ? tab : 'predict');
  if (tab === 'predict' && qs) {
    const p = new URLSearchParams(qs);
    const rank = +p.get('rank');
    if (rank) {
      $('input[name="rank"]').value = rank;
      $('select[name="category"]').value = p.get('category') || 'GEN';
      $('select[name="type"]').value = p.get('type') || '';
      const qv = p.get('quota') || 'GUJCET_Rank';
      const qsel = $('select[name="quota"]'); if (qsel) qsel.value = qv;
      const grp = p.get('group') || '';
      const br = p.get('branch') || '';
      if (grp) { $('#groupPickPredict').value = grp; populateBranchPicker(grp); }
      if (br) $('#branchPickPredict').value = br;
      runPredict({ rank, category: p.get('category'), type: p.get('type'), quota: qv, group: grp, branch: br });
    }
  }
}

(async () => {
  await loadData();
  wireEvents();
  saveShortlist();
  applyHashState();
})();
