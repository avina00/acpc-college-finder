// ACPC Cutoff static app — vanilla JS, no build step.

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const fmt = n => n.toLocaleString('en-IN');

// GA4 event helper (no-op if gtag missing)
const track = (event, params) => {
  try { window.gtag && window.gtag('event', event, params || {}); } catch (_) {}
};

const STATE = {
  data: null,
  shortlist: JSON.parse(localStorage.getItem('acpc.shortlist') || '[]'),
  compare: [],
  lastPredict: null,
  bucketShow: { safe: true, mid: true, reach: true },
  predictQ: '',
};

const saveShortlist = () => {
  localStorage.setItem('acpc.shortlist', JSON.stringify(STATE.shortlist));
  const el = $('#shortlist-count');
  if (el) {
    el.textContent = STATE.shortlist.length || '';
    el.style.display = STATE.shortlist.length ? '' : 'none';
  }
};

function openSidebar() {
  $('#sidebar')?.classList.add('open');
  const bd = $('#sb-backdrop'); if (bd) bd.hidden = false;
}
function closeSidebar() {
  $('#sidebar')?.classList.remove('open');
  const bd = $('#sb-backdrop'); if (bd) bd.hidden = true;
}

// ----- TABS -----
function showTab(name) {
  $$('[data-panel]').forEach(s => s.hidden = s.dataset.panel !== name);
  $$('.tab-btn').forEach(b => {
    const active = b.dataset.tab === name;
    b.classList.toggle('active', active);
  });
  history.replaceState(null, '', `#${name}`);
  track('tab_view', { tab: name });
  // close sidebar on mobile after tab change
  closeSidebar();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (name === 'shortlist') renderShortlist();
  if (name === 'compare') renderCompareControls();
  if (name === 'colleges') renderColleges();
  if (name === 'branches') renderBranches();
  if (name === 'faq') renderFAQ();
}

// ----- FAQ -----
const faqState = { q: '', section: '' };
function renderFAQ() {
  const wrap = $('#faqList');
  const secWrap = $('#faqSections');
  if (!STATE.faq?.faqs?.length) { wrap.innerHTML = '<div class="text-slate-500 text-sm">FAQ unavailable.</div>'; return; }
  const sections = [...new Set(STATE.faq.faqs.map(f => f.section))];
  secWrap.innerHTML = ['', ...sections].map(s => {
    const active = (faqState.section === s);
    return `<button data-sec="${s}" class="faq-sec text-xs px-2.5 py-1 rounded-full border ${active ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-700 hover:bg-slate-50'}">${s || 'All'}</button>`;
  }).join('');
  secWrap.querySelectorAll('[data-sec]').forEach(b => b.onclick = () => { faqState.section = b.dataset.sec; renderFAQ(); });

  const q = faqState.q.toLowerCase();
  const list = STATE.faq.faqs.filter(f => {
    if (faqState.section && f.section !== faqState.section) return false;
    if (q && !(f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q))) return false;
    return true;
  });
  wrap.innerHTML = list.map((f, i) => {
    const src = STATE.faq.sources[f.source] || '#';
    return `<details class="bg-white border rounded-lg p-3 group" ${i < 3 ? 'open' : ''}>
      <summary class="cursor-pointer font-semibold text-sm flex justify-between gap-2">
        <span>${escapeHtml(f.q)}</span>
        <span class="text-[10px] uppercase tracking-wide bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full shrink-0">${escapeHtml(f.section)}</span>
      </summary>
      <p class="text-sm text-slate-700 mt-2 leading-relaxed whitespace-pre-line">${escapeHtml(f.a)}</p>
      <a class="text-xs text-indigo-600 underline mt-2 inline-block" target="_blank" rel="noopener" href="${src}">📄 Source: official ACPC document</a>
    </details>`;
  }).join('') || '<div class="text-slate-500 text-sm bg-white border rounded-lg p-6 text-center">No FAQ matches.</div>';
}
function escapeHtml(s) { return s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

// ----- BUCKETS -----
// Rule: if your rank is below closing rank by a meaningful margin -> Likely.
// "Meaningful" scales with rank: max(3, 2% of rank). So:
//   rank 185 vs close 191 -> buffer 6 >= max(3, 4)=4  -> LIKELY
//   rank 185 vs close 187 -> buffer 2 <  max(3, 4)=4  -> MAYBE
//   rank 15000 vs close 15400 -> buffer 400 >= max(3,300)=300 -> LIKELY
//   rank 15000 vs close 15100 -> buffer 100 <  300 -> MAYBE
//   rank 15000 vs close 14800 -> rank just past close (within 5%) -> MAYBE
//   rank 15000 vs close 12000 -> well past -> REACH
function bucket(rank, lastRank) {
  const buffer = lastRank - rank;
  const need = Math.max(3, Math.round(rank * 0.02));
  if (buffer >= need) return 'safe';
  if (lastRank >= rank * 0.95) return 'mid';   // user up to 5% above closing
  if (lastRank >= rank * 0.75) return 'reach';
  return null;
}
const BUCKET_META = {
  safe:  { label: '🟢 Likely', color: 'bg-emerald-50 border-emerald-200', chip: 'bg-emerald-100 text-emerald-800' },
  mid:   { label: '🟡 Maybe',  color: 'bg-amber-50 border-amber-200',     chip: 'bg-amber-100 text-amber-800' },
  reach: { label: '🔴 Reach',  color: 'bg-rose-50 border-rose-200',       chip: 'bg-rose-100 text-rose-800' },
};

// ----- PREDICT -----
function rowKey(r) { return `${r.institute}::${r.branch}::${r.category}::${r.type}::${r.round || ''}::${r.quota || ''}`; }
function isSaved(r) { return STATE.shortlist.some(s => s.key === rowKey(r)); }

function toggleSave(r, btn) {
  const k = rowKey(r);
  const i = STATE.shortlist.findIndex(s => s.key === k);
  if (i >= 0) {
    STATE.shortlist.splice(i, 1);
    track('shortlist_remove', { branch: r.branch });
  } else {
    STATE.shortlist.push({ key: k, ...r });
    track('shortlist_add', { branch: r.branch, round: r.round, type: r.type });
  }
  saveShortlist();
  if (btn) btn.textContent = isSaved(r) ? '⭐ Saved' : '☆ Save';
}

function rowCard(r, bk) {
  const meta = BUCKET_META[bk] || { color: 'bg-white border-slate-200', chip: 'bg-slate-100 text-slate-700' };
  const saved = isSaved(r);
  const el = document.createElement('div');
  el.className = `border rounded-lg p-3 ${meta.color} flex flex-wrap items-center gap-2`;
  el.innerHTML = `
    <div class="flex-1 min-w-0">
      <div class="font-semibold text-sm leading-snug">${r.institute}</div>
      <div class="text-xs text-slate-600 mt-0.5">${r.branch}</div>
      <div class="flex flex-wrap gap-1 mt-1.5">
        <span class="text-xs px-2 py-0.5 rounded-full ${meta.chip}">${meta.label || ''}</span>
        <span class="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">${r.category}</span>
        <span class="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">${r.type}</span>
      </div>
    </div>
    <div class="text-right">
      <div class="text-xs text-slate-500">Closing rank</div>
      <div class="text-lg font-bold tabular-nums">${fmt(r.last_rank)}</div>
      <div class="text-[10px] text-slate-400">opens ${fmt(r.first_rank)}</div>
    </div>
    <button class="save-btn text-sm px-2 py-1 rounded-md border bg-white hover:bg-slate-50">${saved ? '⭐ Saved' : '☆ Save'}</button>
  `;
  el.querySelector('.save-btn').addEventListener('click', e => toggleSave(r, e.currentTarget));
  return el;
}

function syncBucketToggles() {
  ['safe', 'mid', 'reach'].forEach(bk => {
    const on = STATE.bucketShow[bk];
    const card = document.querySelector(`[data-bk="${bk}"]`);
    if (!card) return;
    card.classList.toggle('opacity-40', !on);
    card.classList.toggle('grayscale', !on);
    const chk = $('#chk-' + bk);
    if (chk) chk.textContent = on ? '✓ shown' : '✗ hidden';
  });
}

function rerenderPredict() {
  if (STATE.lastPredict) runPredict(STATE.lastPredict);
}

function populateBranchPicker(group) {
  const bp = $('#branchPickPredict');
  if (!bp) return;
  const branches = group ? (STATE.data.branch_groups[group] || []) : STATE.data.branches;
  bp.innerHTML = `<option value="">${group ? `All in ${group} (${branches.length})` : 'All in selected group'}</option>` +
    branches.map(b => `<option>${b}</option>`).join('');
}

function runPredict(opts) {
  const { rank, category, type, branch, group, quota, round } = opts;
  const q = quota || 'GUJCET';
  const rnd = round || STATE.data.meta.default_round;
  const matches = STATE.data.rows.filter(r => {
    if (r.round !== rnd) return false;
    if (r.quota !== q) return false;
    if (category && r.category !== category) return false;
    if (type && r.type !== type) return false;
    if (group && r.branch_group !== group) return false;
    if (branch && r.branch !== branch) return false;
    const bk = bucket(rank, r.last_rank);
    return bk !== null;
  }).map(r => ({ r, bk: bucket(rank, r.last_rank) }));

  matches.sort((a, b) => {
    const order = { safe: 0, mid: 1, reach: 2 };
    if (order[a.bk] !== order[b.bk]) return order[a.bk] - order[b.bk];
    return a.r.last_rank - b.r.last_rank;
  });

  const counts = { safe: 0, mid: 0, reach: 0 };
  matches.forEach(m => counts[m.bk]++);

  $('#bucket-counts').hidden = false;
  $('#bk-help').hidden = false;
  $('#predictSearch').hidden = false;
  $('#cnt-safe').textContent = counts.safe;
  $('#cnt-mid').textContent = counts.mid;
  $('#cnt-reach').textContent = counts.reach;
  syncBucketToggles();

  const summary = $('#predict-summary');
  summary.hidden = false;
  const qLabel = q === 'JEE' ? 'JEE Main' : 'GUJCET';
  const rLabel = (STATE.data.meta.rounds.find(rr => rr.key === rnd) || {}).label || rnd;
  summary.innerHTML = `<b>${matches.length}</b> matches · <b>${rLabel}</b> · <b>${qLabel}</b> rank <b>${fmt(rank)}</b>${category ? ` · ${category}` : ''}${type ? ` · ${type}` : ''}${group ? ` · ${group}` : ''}${branch ? ` · ${branch}` : ''}.`;

  const container = $('#predict-results');
  container.innerHTML = '';
  if (matches.length === 0) {
    // suggest other rounds with data for same rank
    const altRounds = (STATE.data.meta.rounds || [])
      .filter(rr => rr.key !== rnd)
      .map(rr => {
        const n = STATE.data.rows.filter(r2 => r2.round === rr.key && r2.quota === q && (!category || r2.category === category) && (!type || r2.type === type) && (!group || r2.branch_group === group) && (!branch || r2.branch === branch) && bucket(rank, r2.last_rank) !== null).length;
        return { ...rr, count: n };
      })
      .filter(rr => rr.count > 0)
      .sort((a, b) => b.count - a.count);
    const hint = altRounds.length
      ? `<div class="mt-3 text-sm text-slate-700">Try another round:<div class="flex flex-wrap gap-2 mt-2">${altRounds.map(rr => `<button class="alt-round bg-indigo-600 text-white px-3 py-1.5 rounded-md text-xs font-semibold" data-round="${rr.key}">${rr.label} → ${rr.count} matches</button>`).join('')}</div></div>`
      : `<div class="mt-3 text-xs text-slate-500">No matches in any round with current filters. Try removing branch / category / type filters.</div>`;
    container.innerHTML = `<div class="bg-white border rounded-lg p-6 text-center"><div class="text-3xl mb-2">🤔</div><div class="text-slate-700 font-semibold">No matches in <b>${rLabel}</b></div><p class="text-xs text-slate-500 mt-1">Top branches usually fill by Round 2 — later rounds have fewer seats.</p>${hint}</div>`;
    container.querySelectorAll('.alt-round').forEach(b => b.onclick = () => {
      const newRnd = b.dataset.round;
      $('#roundPick').value = newRnd;
      runPredict({ ...opts, round: newRnd });
    });
    return;
  }
  // group by bucket — respect bucketShow toggles + text filter
  const qFilter = (STATE.predictQ || '').toLowerCase().trim();
  const cityMap = Object.fromEntries((STATE.data.colleges || []).map(c => [c.name, c.city || '']));
  const passText = r => {
    if (!qFilter) return true;
    const hay = (r.institute + ' ' + r.branch + ' ' + (cityMap[r.institute] || '')).toLowerCase();
    return hay.includes(qFilter);
  };
  ['safe', 'mid', 'reach'].forEach(bk => {
    if (!STATE.bucketShow[bk]) return;
    const subset = matches.filter(m => m.bk === bk && passText(m.r));
    if (!subset.length) return;
    const h = document.createElement('h3');
    h.className = 'mt-4 mb-1 font-bold text-sm text-slate-700';
    h.textContent = `${BUCKET_META[bk].label} · ${subset.length}`;
    container.appendChild(h);
    subset.slice(0, 200).forEach(m => container.appendChild(rowCard(m.r, m.bk)));
    if (subset.length > 200) {
      const more = document.createElement('div');
      more.className = 'text-xs text-slate-500 text-center py-2';
      more.textContent = `…and ${subset.length - 200} more`;
      container.appendChild(more);
    }
  });

  // shareable URL
  const params = new URLSearchParams({ rank, quota: q, round: rnd, category: category || '', type: type || '', group: group || '', branch: branch || '' });
  const link = $('#share-link');
  link.hidden = false;
  link.href = `${location.pathname}#predict?${params}`;
  link.onclick = e => {
    e.preventDefault();
    const url = `${location.origin}${location.pathname}#predict?${params}`;
    navigator.clipboard?.writeText(url);
    link.textContent = '✓ Link copied';
    setTimeout(() => link.textContent = '🔗 Share this result', 1500);
  };

  STATE.lastPredict = opts;
  track('predict_run', {
    round: rnd,
    quota: q,
    category: category || 'ANY',
    type: type || 'ANY',
    group: group || 'ANY',
    rank_bucket: rank < 500 ? '0-500' : rank < 2000 ? '500-2k' : rank < 5000 ? '2k-5k' : rank < 15000 ? '5k-15k' : rank < 40000 ? '15k-40k' : '40k+',
    matches: matches.length,
  });
}

// ----- COLLEGES -----
const collegeFilters = { q: '', city: '', type: '', under50k: false, under1L: false };
function collegeMatches(c) {
  const q = collegeFilters.q.toLowerCase();
  if (q) {
    const hay = (c.name + ' ' + c.city + ' ' + c.branches.join(' ')).toLowerCase();
    if (!hay.includes(q)) return false;
  }
  if (collegeFilters.city && c.city !== collegeFilters.city) return false;
  if (collegeFilters.type && c.type !== collegeFilters.type) return false;
  if (collegeFilters.under50k && c.fee_min > 50000) return false;
  if (collegeFilters.under1L && c.fee_min > 100000) return false;
  return true;
}
function renderColleges() {
  const list = $('#collegeList');
  list.innerHTML = '';
  const colleges = (STATE.data.colleges || []).filter(collegeMatches);
  $('#collegeCount').textContent = `${colleges.length} colleges`;
  colleges.slice(0, 300).forEach(c => {
    const typeChip = c.type === 'Govt/GIA'
      ? 'bg-emerald-100 text-emerald-800'
      : 'bg-indigo-100 text-indigo-800';
    const card = document.createElement('button');
    card.className = 'text-left bg-white border rounded-lg p-3 hover:bg-indigo-50 hover:border-indigo-300 transition';
    card.innerHTML = `
      <div class="flex items-start justify-between gap-2">
        <div class="font-semibold text-sm leading-snug flex-1 min-w-0">${c.name}</div>
        <span class="text-[10px] px-1.5 py-0.5 rounded-full ${typeChip} shrink-0">${c.type === 'Govt/GIA' ? 'Govt' : 'Private'}</span>
      </div>
      <div class="flex flex-wrap items-center gap-2 mt-2 text-xs text-slate-600">
        <span>📍 ${c.city}</span>
        <span>📚 ${c.branch_count} branches</span>
      </div>
      <div class="flex flex-wrap items-center justify-between gap-2 mt-2 text-xs">
        <span class="text-slate-700">💰 <b>${c.fee_label}</b></span>
        ${c.min_cutoff_gen ? `<span class="text-slate-500">GEN cutoff <b class="text-slate-900 tabular-nums">${fmt(c.min_cutoff_gen)}–${fmt(c.max_cutoff_gen)}</b></span>` : ''}
      </div>`;
    card.onclick = () => showCollegeDetail(c.name);
    list.appendChild(card);
  });
  if (!colleges.length) list.innerHTML = '<div class="col-span-full text-slate-500 text-sm bg-white border rounded-lg p-6 text-center">No colleges match. Loosen filters.</div>';
}
function showCollegeDetail(name) {
  track('college_view', { college: name.slice(0, 80) });
  const c = (STATE.data.colleges || []).find(x => x.name === name);
  const rows = STATE.data.rows.filter(r => r.institute === name && r.quota === 'GUJCET').sort((a, b) => a.last_rank - b.last_rank);
  const wrap = $('#collegeDetail');
  const mapQ = encodeURIComponent(name);
  const websiteQ = encodeURIComponent(name + ' official site');
  wrap.innerHTML = `
    <div class="bg-white rounded-xl shadow-sm p-4">
      <div class="flex items-start justify-between gap-2 flex-wrap mb-3">
        <div class="min-w-0">
          <h3 class="font-bold leading-snug">${name}</h3>
          <div class="text-xs text-slate-500 mt-1 flex flex-wrap gap-x-3 gap-y-1">
            <span>📍 ${c?.city || '—'}</span>
            <span>🏷️ ${c?.type || '—'}</span>
            <span>📚 ${c?.branch_count || rows.length} branches</span>
          </div>
        </div>
        <button class="text-xs text-indigo-600 underline shrink-0" id="closeDetail">✕ close</button>
      </div>

      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mb-4 text-xs">
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">Approx. tuition (FRC band)</div>
          <div class="font-bold text-base text-slate-900">${c?.fee_label || '—'}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">Verify exact fee on FRC notification.</div>
        </div>
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">GEN cutoff range</div>
          <div class="font-bold text-base text-slate-900 tabular-nums">${c?.min_cutoff_gen ? fmt(c.min_cutoff_gen) + '–' + fmt(c.max_cutoff_gen) : '—'}</div>
          <div class="text-[10px] text-slate-400 mt-0.5">2024-25 Mock Round, GUJCET quota</div>
        </div>
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">📦 Placement</div>
          <div class="text-[11px] text-slate-700">Not published here — figures vary widely and self-reported numbers are inconsistent. Check official sources:</div>
          <div class="mt-1 flex flex-col gap-0.5">
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://www.nirfindia.org/Rankings/2024/EngineeringRanking.html">📊 NIRF Engineering 2024</a>
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://www.google.com/search?q=${encodeURIComponent(name + ' placement brochure')}">🔍 Find placement brochure</a>
          </div>
        </div>
        <div class="bg-slate-50 border rounded-lg p-3">
          <div class="text-slate-500">🔗 Quick links</div>
          <div class="flex flex-col gap-0.5 mt-1">
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${mapQ}">🗺️ View on map</a>
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://www.google.com/search?q=${websiteQ}">🌐 Find official website</a>
            <a class="text-indigo-600 underline" target="_blank" rel="noopener" href="https://gujacpc.admissions.nic.in/">🏛️ ACPC portal</a>
          </div>
        </div>
      </div>
      <div class="text-[11px] text-slate-500 mb-3 bg-amber-50 border border-amber-200 rounded-md px-2 py-1.5">
        ⚠️ We publish only verifiable data (name, type, branches, official ACPC cutoffs). Full address, accreditation, hostel & placement details are not yet aggregated — please use the official-website link above.
      </div>

      <div class="overflow-auto -mx-4 px-4">
        <table class="w-full text-sm min-w-[560px]">
          <thead class="text-xs text-slate-500 text-left">
            <tr><th class="py-1">Branch</th><th>Cat</th><th>Round</th><th>Quota</th><th class="text-right">Open</th><th class="text-right">Close</th><th></th></tr>
          </thead>
          <tbody>${rows.map(r => {
            const rndChip = r.round === 'r1' ? 'bg-indigo-100 text-indigo-800' : r.round === 'r2' ? 'bg-purple-100 text-purple-800' : r.round === 'r3' ? 'bg-fuchsia-100 text-fuchsia-800' : 'bg-slate-100 text-slate-700';
            return `
            <tr class="border-t">
              <td class="py-1 pr-2">${r.branch}</td>
              <td><span class="text-xs px-1.5 rounded bg-slate-100">${r.category}</span></td>
              <td><span class="text-xs px-1.5 rounded ${rndChip}">${r.round_label || r.round || ''}</span></td>
              <td class="text-xs">${r.quota}</td>
              <td class="text-right tabular-nums">${fmt(r.first_rank)}</td>
              <td class="text-right tabular-nums font-semibold">${fmt(r.last_rank)}</td>
              <td><button data-key='${rowKey(r)}' class="save-tiny text-xs underline">${isSaved(r) ? '⭐' : '☆'}</button></td>
            </tr>`;
          }).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
  $('#closeDetail').onclick = () => wrap.innerHTML = '';
  wrap.querySelectorAll('.save-tiny').forEach(b => {
    b.onclick = () => {
      const r = rows.find(x => rowKey(x) === b.dataset.key);
      toggleSave(r); b.textContent = isSaved(r) ? '⭐' : '☆';
    };
  });
  wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ----- BRANCHES -----
let branchFilter = '';
function renderBranches() {
  const list = $('#branchList');
  list.innerHTML = '';
  const q = branchFilter.toLowerCase();
  const filtered = STATE.data.branches.filter(n => n.toLowerCase().includes(q)).slice(0, 200);
  filtered.forEach(name => {
    const rowsForBranch = STATE.data.rows.filter(r => r.branch === name);
    const colleges = new Set(rowsForBranch.map(r => r.institute));
    const minCut = Math.min(...rowsForBranch.map(r => r.last_rank));
    const card = document.createElement('button');
    card.className = 'text-left bg-white border rounded-lg p-3 hover:bg-indigo-50';
    card.innerHTML = `
      <div class="font-semibold text-sm">${name}</div>
      <div class="text-xs text-slate-500 mt-1">${colleges.size} colleges · best cutoff ${fmt(minCut)}</div>`;
    card.onclick = () => showBranchDetail(name);
    list.appendChild(card);
  });
  if (!filtered.length) list.innerHTML = '<div class="text-slate-500 text-sm">No matches.</div>';
}
function showBranchDetail(name) {
  track('branch_view', { branch: name.slice(0, 80) });
  const rows = STATE.data.rows.filter(r => r.branch === name && r.quota === 'GUJCET').sort((a, b) => a.last_rank - b.last_rank);
  const wrap = $('#branchDetail');
  wrap.innerHTML = `
    <div class="bg-white rounded-xl shadow-sm p-4">
      <div class="flex items-center justify-between gap-2 flex-wrap mb-3">
        <h3 class="font-bold">${name}</h3>
        <button class="text-xs text-indigo-600 underline" id="closeBDetail">close</button>
      </div>
      <div class="overflow-auto"><table class="w-full text-sm">
        <thead class="text-xs text-slate-500 text-left"><tr><th class="py-1">College</th><th>Cat</th><th>Type</th><th class="text-right">Close</th><th></th></tr></thead>
        <tbody>${rows.map(r => `
          <tr class="border-t">
            <td class="py-1 pr-2">${r.institute}</td>
            <td><span class="text-xs px-1.5 rounded bg-slate-100">${r.category}</span></td>
            <td class="text-xs">${r.type}</td>
            <td class="text-right tabular-nums font-semibold">${fmt(r.last_rank)}</td>
            <td><button data-key='${rowKey(r)}' class="save-tiny text-xs underline">${isSaved(r) ? '⭐' : '☆'}</button></td>
          </tr>`).join('')}</tbody></table></div>
    </div>`;
  $('#closeBDetail').onclick = () => wrap.innerHTML = '';
  wrap.querySelectorAll('.save-tiny').forEach(b => {
    b.onclick = () => {
      const r = rows.find(x => rowKey(x) === b.dataset.key);
      toggleSave(r); b.textContent = isSaved(r) ? '⭐' : '☆';
    };
  });
}

// ----- COMPARE -----
function renderCompareControls() {
  const sel = $('#compareAdd');
  sel.innerHTML = '<option value="">+ Add a college…</option>' +
    STATE.data.institutes
      .filter(n => !STATE.compare.includes(n))
      .map(n => `<option value="${n.replace(/"/g, '&quot;')}">${n}</option>`).join('');
  renderCompareTable();
}
function renderCompareTable() {
  const wrap = $('#compareTable');
  if (!STATE.compare.length) { wrap.innerHTML = '<div class="text-slate-500 text-sm">Pick a college above to start comparing.</div>'; return; }
  const allBranches = [...new Set(STATE.data.rows.filter(r => STATE.compare.includes(r.institute) && r.category === 'GEN' && r.quota === 'GUJCET').map(r => r.branch))].sort();
  wrap.innerHTML = `
    <div class="bg-white rounded-xl shadow-sm p-3 overflow-auto">
      <div class="mb-2 flex flex-wrap gap-2">${STATE.compare.map(n => `<span class="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full">${n} <button data-rm="${n.replace(/"/g, '&quot;')}" class="ml-1 font-bold">×</button></span>`).join('')}</div>
      <table class="w-full text-xs">
        <thead><tr class="text-left text-slate-500"><th class="py-1 pr-2">Branch (GEN closing rank)</th>${STATE.compare.map(n => `<th class="text-right pr-3">${n.split(',')[0].slice(0, 30)}</th>`).join('')}</tr></thead>
        <tbody>${allBranches.map(b => `
          <tr class="border-t"><td class="py-1 pr-2">${b}</td>${STATE.compare.map(n => {
            const row = STATE.data.rows.find(r => r.institute === n && r.branch === b && r.category === 'GEN' && r.quota === 'GUJCET');
            return `<td class="text-right tabular-nums pr-3">${row ? fmt(row.last_rank) : '<span class="text-slate-300">–</span>'}</td>`;
          }).join('')}</tr>`).join('')}</tbody>
      </table>
      <p class="text-[10px] text-slate-400 mt-2">Showing GEN category closing ranks. Use Predict tab for other categories.</p>
    </div>`;
  wrap.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => {
    STATE.compare = STATE.compare.filter(n => n !== b.dataset.rm);
    renderCompareControls();
  });
}

// ----- SHORTLIST -----
function renderShortlist() {
  const wrap = $('#shortlistView');
  if (!STATE.shortlist.length) {
    wrap.innerHTML = `<div class="bg-white border rounded-lg p-6 text-center text-slate-500">No saved colleges yet. Hit ☆ Save on any result.</div>`;
    return;
  }
  wrap.innerHTML = `<div class="bg-white rounded-xl shadow-sm overflow-auto"><table class="w-full text-sm">
    <thead class="text-xs text-slate-500 text-left"><tr><th class="py-2 px-3">College</th><th>Branch</th><th>Cat</th><th>Type</th><th class="text-right pr-3">Close</th><th></th></tr></thead>
    <tbody>${STATE.shortlist.map(r => `
      <tr class="border-t">
        <td class="py-1 px-3">${r.institute}</td><td>${r.branch}</td>
        <td><span class="text-xs px-1.5 rounded bg-slate-100">${r.category}</span></td>
        <td class="text-xs">${r.type}</td>
        <td class="text-right tabular-nums font-semibold pr-3">${fmt(r.last_rank)}</td>
        <td><button data-rm="${r.key}" class="text-rose-600 text-xs">remove</button></td>
      </tr>`).join('')}</tbody></table></div>`;
  wrap.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => {
    STATE.shortlist = STATE.shortlist.filter(s => s.key !== b.dataset.rm);
    saveShortlist(); renderShortlist();
  });
}

function shareWhatsApp() {
  if (!STATE.shortlist.length) return;
  track('share_whatsapp', { count: STATE.shortlist.length });
  const lines = STATE.shortlist.map((r, i) => `${i + 1}. ${r.institute} — ${r.branch} (${r.category}, close ${fmt(r.last_rank)})`).join('\n');
  const msg = `My ACPC shortlist:\n\n${lines}\n\nSource: ${location.origin}${location.pathname}`;
  window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
}

// ----- INIT -----
async function loadData() {
  const [res, fres] = await Promise.all([
    fetch('data/data.json'),
    fetch('data/faq.json').catch(() => null),
  ]);
  STATE.data = await res.json();
  STATE.faq = fres ? await fres.json() : { faqs: [], sources: {} };
  const m = STATE.data.meta;
  const roundLabels = (m.rounds || []).map(r => r.label).join(' + ') || 'Mock Round';
  $('#meta-line').textContent = `${roundLabels} · A.Y. ${m.year} · ${fmt(m.rows)} cutoffs · ${fmt(STATE.data.institutes.length)} colleges`;

  // round picker
  const rp = $('#roundPick');
  if (rp && m.rounds?.length) {
    rp.innerHTML = m.rounds.map(r => `<option value="${r.key}" ${r.key === m.default_round ? 'selected' : ''}>${r.label} (${fmt(r.rows)})</option>`).join('');
  }

  // group + branch pickers on predict
  const groups = STATE.data.branch_groups || {};
  const gp = $('#groupPickPredict');
  if (gp) {
    const entries = Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
    gp.innerHTML = '<option value="">All branches</option>' +
      entries.map(([g, bs]) => `<option value="${g}">${g} (${bs.length})</option>`).join('');
  }
  populateBranchPicker('');

  // city dropdown for college tab
  const cityEl = $('#collegeCity');
  if (cityEl && STATE.data.cities) {
    cityEl.innerHTML = '<option value="">All cities</option>' + STATE.data.cities.map(c => `<option>${c}</option>`).join('');
  }
}

function wireEvents() {
  $('#tabs').addEventListener('click', e => {
    const b = e.target.closest('.tab-btn'); if (b) showTab(b.dataset.tab);
  });
  $('#predict-form').addEventListener('submit', e => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    runPredict({
      rank: +fd.get('rank'),
      category: fd.get('category'),
      type: fd.get('type'),
      quota: fd.get('quota') || 'GUJCET',
      round: fd.get('round') || STATE.data.meta.default_round,
      group: $('#groupPickPredict')?.value || '',
      branch: $('#branchPickPredict')?.value || '',
    });
  });
  $('#groupPickPredict')?.addEventListener('change', e => populateBranchPicker(e.target.value));
  document.querySelectorAll('.bk-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const bk = btn.dataset.bk;
      STATE.bucketShow[bk] = !STATE.bucketShow[bk];
      // prevent all off
      if (!Object.values(STATE.bucketShow).some(v => v)) STATE.bucketShow[bk] = true;
      syncBucketToggles();
      rerenderPredict();
    });
  });
  $('#collegeSearch').addEventListener('input', e => { collegeFilters.q = e.target.value; renderColleges(); });
  $('#collegeCity').addEventListener('change', e => { collegeFilters.city = e.target.value; renderColleges(); });
  $('#collegeType').addEventListener('change', e => { collegeFilters.type = e.target.value; renderColleges(); });
  $('#feeUnder50k').addEventListener('change', e => { collegeFilters.under50k = e.target.checked; if (e.target.checked) { $('#feeUnder1L').checked = false; collegeFilters.under1L = false; } renderColleges(); });
  $('#feeUnder1L').addEventListener('change', e => { collegeFilters.under1L = e.target.checked; if (e.target.checked) { $('#feeUnder50k').checked = false; collegeFilters.under50k = false; } renderColleges(); });
  $('#branchSearch').addEventListener('input', e => { branchFilter = e.target.value; renderBranches(); });
  $('#compareAdd').addEventListener('change', e => {
    const v = e.target.value;
    if (v && STATE.compare.length < 4 && !STATE.compare.includes(v)) STATE.compare.push(v);
    renderCompareControls();
  });
  $('#shareWA').onclick = shareWhatsApp;
  $('#printList').onclick = () => window.print();
  $('#clearList').onclick = () => { if (confirm('Clear all saved colleges?')) { STATE.shortlist = []; saveShortlist(); renderShortlist(); } };
  $('#faqSearch')?.addEventListener('input', e => { faqState.q = e.target.value; renderFAQ(); });
  $('#predictSearch')?.addEventListener('input', e => { STATE.predictQ = e.target.value; rerenderPredict(); });
  $('#closeDisc')?.addEventListener('click', () => {
    $('#disclaimer').style.display = 'none';
    localStorage.setItem('acpc.disc', '1');
  });
  if (localStorage.getItem('acpc.disc')) $('#disclaimer').style.display = 'none';
  $('#hamburger')?.addEventListener('click', openSidebar);
  $('#sb-backdrop')?.addEventListener('click', closeSidebar);
}

function applyHashState() {
  const [tab, qs] = (location.hash.slice(1) || 'predict').split('?');
  showTab(['predict','colleges','branches','compare','shortlist','faq','about'].includes(tab) ? tab : 'predict');
  if (tab === 'predict' && qs) {
    const p = new URLSearchParams(qs);
    const rank = +p.get('rank');
    if (rank) {
      $('input[name="rank"]').value = rank;
      $('select[name="category"]').value = p.get('category') || 'GEN';
      $('select[name="type"]').value = p.get('type') || '';
      const qv = p.get('quota') || 'GUJCET';
      const qsel = $('select[name="quota"]'); if (qsel) qsel.value = qv;
      const rnd = p.get('round') || STATE.data.meta.default_round;
      const rsel = $('#roundPick'); if (rsel) rsel.value = rnd;
      const grp = p.get('group') || '';
      const br = p.get('branch') || '';
      if (grp) { $('#groupPickPredict').value = grp; populateBranchPicker(grp); }
      if (br) $('#branchPickPredict').value = br;
      runPredict({ rank, category: p.get('category'), type: p.get('type'), quota: qv, round: rnd, group: grp, branch: br });
    }
  }
}

(async () => {
  await loadData();
  wireEvents();
  saveShortlist();
  applyHashState();
})();
